The files in this directory are provided for convenience, they are not
maintained to the same standard as the rest of the project.
