#include "TypeAccumulator.hpp"
// !! Test that the template class compiles cleanly !!
