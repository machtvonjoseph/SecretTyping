Installation
============

Pre-built Debian packages are available from the `releases page`_.

You can download Docker images from GHCR or them build yourself; see
:doc:`docker`.

If you need to use a older version of LLVM, you'll have to build from source.
See :doc:`build`.

.. _releases page: https://github.com/GaloisInc/cclyzerpp/releases
