#include <stdio.h>

int main(int argc, char const *argv[]) {
  printf("this is a very small program\n");
  return 0;
}
